<h1 align = "center"><font size='6'>CS305 Course Project: Research on IPv6 Network Protocol</h1>

<h1 align = "center"><font size='4'>Name: 吉辰卿 &nbsp&nbsp张旭东 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ID: 11911303&nbsp &nbsp 12011923</h1>



## Part 1: Basic information about IPv6

